<?php
require_once __DIR__ . '/domain.php';
function checklistRows(PDO $pdo, int $bookingId): array
{
    $q = $pdo->prepare('SELECT c.*,checklist_item_id AS booking_item_id,item_name_snapshot AS name,expected_quantity AS expected_qty,quantity_released AS released_qty,quantity_returned AS returned_qty,condition_in AS `condition`,IF(COALESCE(quantity_released,0)=expected_quantity,1,0) AS checked_released,notes FROM booking_checklist_items c WHERE booking_id=? ORDER BY checklist_item_id');
    $q->execute([$bookingId]);
    return $q->fetchAll();
}
function copyBookingChecklist(PDO $pdo, int $bookingId, ?int $packageId): array
{
    lockBooking($pdo, $bookingId);
    $existing = checklistRows($pdo, $bookingId);
    if ($existing) return $existing;
    if (!$packageId) return [];
    $q = $pdo->prepare("SELECT template_id FROM checklist_templates WHERE package_id=? AND status='Active' ORDER BY template_id FOR UPDATE");
    $q->execute([$packageId]);
    $templates = $q->fetchAll(PDO::FETCH_COLUMN);
    if (count($templates) > 1) domainFail('The package has multiple active checklist templates.');
    if ($templates) $pdo->prepare('INSERT INTO booking_checklist_items(booking_id,template_item_id,item_name_snapshot,expected_quantity) SELECT ?,template_item_id,item_name,expected_quantity FROM checklist_template_items WHERE template_id=? ORDER BY template_item_id')->execute([$bookingId, $templates[0]]);
    return checklistRows($pdo, $bookingId);
}
function updateChecklistItem(PDO $pdo, int $bookingId, int $itemId, array $body, int $ownerId): array
{
    $booking = lockBooking($pdo, $bookingId);
    if (in_array($booking['status'], ['Awaiting Payment', 'Completed', 'Cancelled'], true)) domainFail('Historical checklists cannot be edited.');
    $q = $pdo->prepare('SELECT * FROM booking_checklist_items WHERE checklist_item_id=? AND booking_id=? FOR UPDATE');
    $q->execute([$itemId, $bookingId]);
    $old = $q->fetch();
    if (!$old) domainFail('Checklist item not found.', 404, 'not_found');
    $release = $pdo->prepare('SELECT 1 FROM item_releases WHERE booking_id=? LIMIT 1 FOR UPDATE');
    $release->execute([$bookingId]);
    if ($release->fetchColumn()) {
        $requestedReleased = $body['quantity_released'] ?? $body['released_qty'] ?? $old['quantity_released'];
        $requestedCondition = array_key_exists('condition_out', $body) ? $body['condition_out'] : $old['condition_out'];
        if ((string)$requestedReleased !== (string)$old['quantity_released'] || $requestedCondition !== $old['condition_out']) {
            domainFail('Released quantities and conditions cannot change after dispatch.', 409, 'released_checklist_locked');
        }
    }
    $releasedValue = $body['quantity_released'] ?? $body['released_qty'] ?? (array_key_exists('checked_released', $body) ? (!empty($body['checked_released']) ? $old['expected_quantity'] : 0) : $old['quantity_released']);
    $released = asInt($releasedValue, 0);
    $returned = asInt($body['quantity_returned'] ?? $body['returned_qty'] ?? $old['quantity_returned'], 0);
    if ($released === null || $returned === null || $released < 0 || $returned < 0 || $released > (int)$old['expected_quantity'] || $returned > $released) domainFail('Quantities must be non-negative and satisfy returned <= released <= expected.');
    $out = array_key_exists('condition_out', $body) ? $body['condition_out'] : $old['condition_out'];
    if ($released > 0 && !$out && !empty($body['checked_released'])) $out = 'Good';
    $in = $body['condition_in'] ?? $body['condition'] ?? $old['condition_in'];
    $allowed = ['Good', 'Minor Damage', 'Damaged', 'Missing', 'Unwashed'];
    if (($out !== null && (!is_string($out) || !in_array($out, $allowed, true))) || ($in !== null && (!is_string($in) || !in_array($in, $allowed, true)))) domainFail('Invalid checklist condition.');
    if ($released > 0 && !$out) domainFail('Release condition is required.');
    $status = $in === null ? 'pending' : (($returned < $released || $in === 'Missing') ? 'missing' : (in_array($in, ['Minor Damage', 'Damaged'], true) ? 'damaged' : 'inspected'));
    $notes = $body['notes'] ?? $body['item_notes'] ?? $old['notes'] ?? null;
    $pdo->prepare('UPDATE booking_checklist_items SET quantity_released=?,quantity_returned=?,condition_out=?,condition_in=?,return_status=?,checked_by=?,checked_at=NOW(),notes=? WHERE checklist_item_id=?')->execute([$released, $returned, $out, $in, $status, $ownerId, $notes, $itemId]);
    auditWrite($pdo, $ownerId, 'checklist_updated', 'checklist', $itemId, json_encode(['before' => $old, 'after' => [$released, $returned, $out, $in, $status, $notes]]));
    $q->execute([$itemId, $bookingId]);
    return $q->fetch();
}

function requireEquipmentRecoveryBeforeCancellation(
    PDO $pdo,
    int $bookingId
): void {
    // The booking row is already locked by saveBooking. Treat checklist
    // quantities as the dispatch evidence so an incomplete/legacy release
    // record cannot allow physical equipment to be stranded.
    $unresolved = $pdo->prepare(
        "SELECT checklist_item_id
         FROM booking_checklist_items
         WHERE booking_id = ?
           AND quantity_released > 0
           AND (
               quantity_returned < quantity_released
               OR condition_in IS NULL
               OR TRIM(condition_in) = ''
               OR return_status NOT IN ('inspected', 'damaged')
           )
         LIMIT 1
         FOR UPDATE"
    );
    $unresolved->execute([$bookingId]);

    if ($unresolved->fetchColumn()) {
        domainFail(
            'Equipment has already been dispatched. Record the returned quantity and condition for every released item before cancelling this booking.',
            409,
            'equipment_return_required'
        );
    }
}
