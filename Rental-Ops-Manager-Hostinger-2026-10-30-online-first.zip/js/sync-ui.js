﻿(() => {
  let syncing=false,working=false,readError='',refreshTimer=null;
  const onlinePolicySelectors=[
    '#addonForm','#categoryForm','#contentForm','#imageForm','#itemForm','#ownerForm','#packageForm','#templateForm','#serviceForm','#settingsForm',
    '#addAddonBtn','#addCategoryBtn','#addImageBtn','#addItemBtn','#addOwnerBtn','#addPackageBtn','#addServiceBtn',
    '.js-delete-addon','.js-edit-addon','.js-toggle-addon-status','.js-delete-cat','.js-edit-cat','.js-delete-img','.js-edit-img',
    '.js-delete-item','.js-edit-item','.js-owner-password','.js-owner-status','.js-archive-package','.js-edit-package',
    '.js-template-package','.js-template-toggle','.js-delete-service','.js-edit-service','.js-toggle-service-status'
  ].join(',');
  function markOnlineControls(root=document){
    const matches=[];
    if(root.nodeType===1&&root.matches?.(onlinePolicySelectors))matches.push(root);
    root.querySelectorAll?.(onlinePolicySelectors).forEach(node=>matches.push(node));
    matches.forEach(node=>node.setAttribute('data-online-required',''));
  }
  function applyOnlineControlState(){
    markOnlineControls();
    document.querySelectorAll('[data-online-required]').forEach(control=>{
      const targets=control.matches('form')?control.querySelectorAll('button[type="submit"],input,select,textarea'):[control];
      targets.forEach(target=>{
        if(!navigator.onLine&&!target.disabled){target.disabled=true;target.dataset.onlinePolicyDisabled='true';}
        else if(navigator.onLine&&target.dataset.onlinePolicyDisabled==='true'){target.disabled=false;delete target.dataset.onlinePolicyDisabled;}
      });
      control.setAttribute('aria-disabled',navigator.onLine?'false':'true');
      control.classList.toggle('opacity-50',!navigator.onLine);
      if(!navigator.onLine)control.title='Internet connection required';
      else if(control.title==='Internet connection required')control.removeAttribute('title');
    });
  }
  async function runSync(work) {
    if (working) return;
    working=true; readError=''; render();
    try { await work(); }
    catch(error) { readError=error.message || 'Synchronization failed. Please retry.'; }
    finally { working=false; render(); }
  }
  const esc=s=>escapeHtmlA(s);
  window.initSyncPanel=()=>{
    if(!document.querySelector('#syncPanel')){
      const panel=document.createElement('details');panel.id='syncPanel';panel.className='sync-panel border rounded p-3 mb-3 bg-white';
      panel.innerHTML='<summary><span id="syncStatus" role="status" aria-live="polite"></span></summary><p id="offlineSetup" class="small mt-2 mb-2"></p><p class="small text-muted mb-2">Offline recovery is limited to booking drafts, checklist drafts, and return-inspection drafts. Money, approvals, finalization, catalog, settings, and owner changes require internet.</p><p id="syncReadError" class="small text-danger mb-2" role="alert" hidden></p><button type="button" class="btn btn-sm btn-outline-secondary" id="syncNow">Refresh data and sync</button><div id="syncOperations" class="mt-3"></div>';
      document.querySelector('.admin-topbar')?.after(panel);
      panel.querySelector('#syncNow').addEventListener('click', () => runSync(async () => { await API.refreshSharedData(); await API.flushSyncQueue(); }));
      panel.addEventListener('submit',e=>{
        if(e.target.matches('.sync-money-edit')){
          e.preventDefault();const form=e.target,amount=form.elements.amount.value;
          if(!/^\d{1,8}(?:\.\d{1,2})?$/.test(amount)||Number(amount)<=0){form.querySelector('[role=alert]').textContent='Enter a positive amount with at most two decimal places.';return;}
          void runSync(() => API.retrySyncOperation(form.dataset.operation,{[form.dataset.field]:amount}));return;
        }
        if(!e.target.matches('.sync-edit'))return;e.preventDefault();
        const form=e.target,date=form.elements.event_date.value,start=form.elements.start_time.value,end=form.elements.end_time.value,location=form.elements.event_location.value.trim();
        if(!date||!start||!end||start>=end||!location){form.querySelector('[role=alert]').textContent='Choose a location, date and an end time after the start time.';return;}
        void runSync(() => API.retrySyncOperation(form.dataset.operation,{event_date:date,start_time:start,end_time:end,event_location:location}));
      });
      panel.addEventListener('click',e=>{
        const retry=e.target.closest('[data-retry]');
        if(retry){void runSync(() => API.retrySyncOperation(retry.dataset.retry));return;}
        const discard=e.target.closest('[data-discard]');
        if(!discard)return;
        const operation=API.getSyncQueue().find(op=>op.client_id===discard.dataset.discard);
        const label=operation?.data?.customer_name||operation?.local_id||operation?.entity||'this local change';
        if(!window.confirm(`Discard ${label}? This removes only the unsynced local change; accepted server records are not deleted.`))return;
        void runSync(async()=>{API.discardSyncOperation(discard.dataset.discard);if(navigator.onLine)await API.refreshSharedData();});
      });
    }
    if(typeof MutationObserver!=='undefined'&&!window.akadOnlinePolicyObserver){
      window.akadOnlinePolicyObserver=new MutationObserver(records=>{records.forEach(record=>record.addedNodes.forEach(markOnlineControls));applyOnlineControlState();});
      window.akadOnlinePolicyObserver.observe(document.body,{childList:true,subtree:true});
    }
    render();
  };
  function render(){
    const status=document.querySelector('#syncStatus');if(!status)return;
    const ops=API.getSyncQueue(),pending=ops.filter(op=>op.status==='pending').length,conflicts=ops.filter(op=>op.status==='conflict').length,failed=ops.filter(op=>op.status==='failed').length;
    const counts=ops.length?`${pending} pending · ${conflicts} conflicts · ${failed} need attention`:'All changes synced';
    status.textContent=(navigator.onLine?'Online':'Offline')+' · '+(syncing?'Syncing · ':'')+counts;
    const error=document.querySelector('#syncReadError');
    if(error){error.textContent=readError;error.hidden=!readError;}
    document.querySelector('#syncNow').disabled=!navigator.onLine||syncing||working;
    document.querySelectorAll('#syncOperations button').forEach(button=>{button.disabled=working||syncing||!navigator.onLine;});
    applyOnlineControlState();
    document.querySelector('#offlineSetup').textContent=window.akadOfflineReady?'Recovery pages are cached on this device. Offline drafts are not official until the server accepts them; the cache does not download new server data.':'Offline recovery setup is not complete yet. Keep this page online until setup finishes.';
    if(working||document.activeElement?.closest('.sync-edit'))return;

    // Build stale-edit comparison table for conflicts
    function staleComparison(op) {
      if (!op.server_record || !op.data._base) return '';
      const base = op.data._base;
      const server = op.server_record;
      const local = op.data;
      const keys = Object.keys(base);
      const rows = [...keys].filter(k => {
        const b = base[k], s = server[k], l = local[k];
        return b !== s || b !== l || s !== l;
      }).map(k => {
        const b = base[k] ?? '';
        const s = server[k] ?? '';
        const l = local[k] ?? '';
        return `<tr><th scope="row">${esc(k)}</th><td>${esc(b)}</td><td>${esc(s)}</td><td>${esc(l)}</td></tr>`;
      }).join('');
      if (!rows) return '';
      return `<details class="mt-2"><summary class="small text-muted">Stale-edit comparison</summary>
        <table class="table table-sm table-bordered mt-2" style="font-size:.8rem;">
          <thead><tr><th>Field</th><th>Your previous</th><th>Server now</th><th>Your change</th></tr></thead>
          <tbody>${rows}</tbody>
        </table></details>`;
    }

    document.querySelector('#syncOperations').innerHTML=ops.length ? ops.map(op=>{
      const booking=STORAGE.getAll('bookings').find(b=>String(b.id)===String(op.local_id)),draft={...booking,...op.data};
      const comparison = staleComparison(op);
      const moneyField=op.entity==='payments'?'amount':op.entity==='deposits'?(op.action==='upsert'?'amount_held':op.action==='deduct'?'amount':null):null;
      const moneyEditor=moneyField&&['failed','conflict'].includes(op.status)?`<form class="sync-money-edit row g-2 mt-2" data-operation="${esc(op.client_id)}" data-field="${esc(moneyField)}"><div class="col-sm-6"><label for="money-${op.client_id}">Corrected amount</label><input required class="form-control" id="money-${op.client_id}" name="amount" inputmode="decimal" value="${esc(op.data[moneyField]??'')}"></div><div class="col-sm-6 align-self-end"><button class="btn btn-sm btn-admin-primary">Correct and retry</button></div><div role="alert" class="text-danger small"></div></form>`:'';
      const editor=op.entity==='bookings'&&['conflict','failed'].includes(op.status)?`<details><summary>Edit booking event details and retry</summary>${comparison}<form class="sync-edit row g-2 mt-1" data-operation="${esc(op.client_id)}">
        <div class="col-sm-4"><label for="date-${op.client_id}">Event date</label><input required class="form-control" id="date-${op.client_id}" name="event_date" type="date" value="${esc(draft.event_date||'')}"></div>
        <div class="col-sm-4"><label for="start-${op.client_id}">Start time</label><input required class="form-control" id="start-${op.client_id}" name="start_time" type="time" value="${esc(String(draft.start_time||'').slice(0,5))}"></div>
        <div class="col-sm-4"><label for="end-${op.client_id}">End time</label><input required class="form-control" id="end-${op.client_id}" name="end_time" type="time" value="${esc(String(draft.end_time||'').slice(0,5))}"></div>
        <div class="col-12"><label for="location-${op.client_id}">Event location</label><input required class="form-control" id="location-${op.client_id}" name="event_location" type="text" value="${esc(draft.event_location||draft.location||'')}"></div>
        <div role="alert" class="text-danger small"></div><div><button class="btn btn-sm btn-admin-primary">Apply and retry</button></div></form></details>`:'';
      const discard=['failed','conflict'].includes(op.status)?`<button type="button" class="btn btn-sm btn-outline-danger ms-2" data-discard="${esc(op.client_id)}">Discard local change</button>`:'';
      return `<article class="border-top py-2"><strong>${esc(op.entity)} · ${esc(op.action)}</strong><span class="badge bg-secondary ms-2">${esc(op.status==='pending'?'Pending Sync':op.status)}</span><p class="small mb-1">${esc(draft.customer_name||op.local_id||'')} ${esc(draft.event_date||'')}</p>${op.reason?`<p class="text-danger small" role="alert">${esc(op.reason)} Your draft is retained.</p>`:''}${moneyEditor}${editor}${op.status==='failed'&&!editor&&!moneyEditor?`<button type="button" class="btn btn-sm btn-outline-secondary" data-retry="${op.client_id}">Retry</button>`:''}${discard}</article>`;
    }).join(''):'<p class="small text-muted mb-0">No pending changes for this signed-in user.</p>';
  }
  window.addEventListener('sync-state-changed',e=>{if(e.detail?.syncing!==undefined)syncing=e.detail.syncing;render();});
  window.addEventListener('offline-ready',render);
  document.addEventListener('click',event=>{
    if(navigator.onLine||!event.target.closest?.('[data-online-required]'))return;
    event.preventDefault();event.stopImmediatePropagation();
    window.showAdminToast?.('This action requires an internet connection.','warning');
  },true);
  document.addEventListener('submit',event=>{
    if(navigator.onLine||!event.target.matches?.('[data-online-required]'))return;
    event.preventDefault();event.stopImmediatePropagation();
    window.showAdminToast?.('This action requires an internet connection.','warning');
  },true);
  document.addEventListener('input',e=>{const modal=e.target.closest('#bookingDetailModal');if(modal)modal.dataset.edited='true';});
  document.addEventListener('change',e=>{const modal=e.target.closest('#bookingDetailModal');if(modal)modal.dataset.edited='true';});
  document.addEventListener('hidden.bs.modal',e=>{if(e.target.id==='bookingDetailModal')delete e.target.dataset.edited;});
  window.addEventListener('api-data-changed',event=>{
    const page=location.pathname.split('/').pop();
    const entity=event.detail?.entity;
    if(entity==='delivery'||entity==='deposits')return;
    window.clearTimeout(refreshTimer);
    refreshTimer=window.setTimeout(async()=>{
      try {
      if(page==='calendar.html'&&typeof CalendarHelper!=='undefined')await CalendarHelper.render('#calendarWrap',typeof showBookingPeek==='function'?showBookingPeek:null);
      if(page==='bookings.html'&&typeof renderBookingsTable==='function')await renderBookingsTable($('#filterStatus').val(),$('#filterSearch').val());
      if(page==='services.html'&&typeof renderServicesTable==='function')await renderServicesTable();
      if(page==='categories.html'&&typeof renderCategoriesTable==='function')await renderCategoriesTable();
      if(page==='addons.html'&&typeof renderAddonsTable==='function')await renderAddonsTable();
      if(page==='inventory.html'&&typeof renderInventory==='function')await renderInventory($('#invSearch').val());
      if(page==='gallery.html'&&typeof renderGallery==='function')await renderGallery();
      if(page==='customers.html'&&typeof renderCustomers==='function')await renderCustomers($('#custSearch').val());
      if(page==='payments.html'&&typeof renderPayments==='function')await renderPayments();
      if(page==='dashboard.html'&&typeof renderDashboard==='function'){await renderDashboard();$('#dashboardDataState').text('Dashboard refreshed from updated saved data.');}
      if(page==='reports.html'&&typeof renderReport==='function'){await renderReport($('#reportStartDate').val(),$('#reportEndDate').val());$('#reportDataState').text('Report refreshed from updated saved data.');}
      if(entity==='settings'&&typeof updateAdminSidebarBrand==='function'){
        updateAdminSidebarBrand();
      }
      render();
      } catch(error) { readError=error.message; render(); }
    },100);
    const modal=document.querySelector('#bookingDetailModal.show');
    if(modal&&!modal.dataset.edited&&typeof loadBookingDetail==='function'&&typeof currentBookingId!=='undefined')loadBookingDetail(currentBookingId).catch(error=>{readError=error.message;render();});
  });
  window.addEventListener('api-read-error',event=>{
    readError='Could not refresh '+(event.detail?.entity||'saved data')+': '+(event.detail?.message||'Check the connection and retry.');
    const message='Could not refresh '+(event.detail?.entity||'saved data')+': showing the last saved values.';
    if(location.pathname.endsWith('/dashboard.html'))$('#dashboardDataState').text(message);
    if(location.pathname.endsWith('/reports.html'))$('#reportDataState').text(message);
    render();
  });
})();
